console.log("Code Pynk is cool")
//i can try 
console.log("Hello Girls");

//hey y'all i'm currently typing can you see what i'm doing? woooooooooo i'm typing!!! :D
//can you type too? 
//typing 

console.log("This is so much better")


hellooooo world

    